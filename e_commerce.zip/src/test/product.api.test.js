const request = require("supertest");

jest.doMock("../config/redis", () => ({
  get: jest.fn(),
  setEx: jest.fn(),
  del: jest.fn(),
}));

jest .doMock("../model/product.model", () => ({
  addProduct: jest.fn(),
  getProducts: jest.fn(),
  getProductById: jest.fn(),
  getProductsByIds: jest.fn(),
  updateProduct: jest.fn(),
  updateQuantity: jest.fn(),
  deleteProduct: jest.fn()
}));

jest.doMock("../utility/redis.util", () => jest.fn());

jest.doMock("../middleware/auth.middleware", () => {
  return (req, res, next) => {
    const token = req.headers.authorization;

    if (!token) {
      return res.status(401).json({
        message: "Unauthorized",
      });
    }

    if (token === "Bearer admin-token") {
      req.user = {
        id: 7,
        role: "admin",
      };

      return next();
    }

    if (token === "Bearer valid-user-token") {
      req.user = {
        id: 7,
        role: "user",
      };

      return next();
    }

    if (token === "Bearer regular-user-token") {
      req.user = {
        id: 7,
        role: "user",
      };

      return res.status(403).json({
        message: "Forbidden",
      });
    }

    return res.status(401).json({
      message: "Unauthorized",
    });
  };
});

const app = require("../app");
const redis = require("../config/redis");
const Product = require("../model/product.model");
const clearCacheByPattern = require("../utility/redis.util");